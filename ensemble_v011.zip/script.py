# script.py
#
# ensemble_v011 final inference
#
# train.py에서 생성된
#
#   ./model/ensemble_v011/ensemble_v011.pkl
#
# 을 로드하여
#
#   0.70 * CatBoostRegressor
# + 0.30 * XGBRegressor
#
# probability를 생성한다.
#
# 평가 데이터 독립 추론:
# - 모든 preprocessing 객체는 official train에서 fit된 frozen object.
# - test에서 fit / groupby / rolling / rank / mean 등을 수행하지 않는다.
# - 각 test row prediction은 다른 test row와 독립적이다.


from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np
import pandas as pd


# ============================================================
# 경로
# ============================================================

EXPERIMENT_NAME = "ensemble_v011"

DATA_DIR = Path("./data")

MODEL_ROOT = Path("./model")
MODEL_DIR = MODEL_ROOT / EXPERIMENT_NAME
MODEL_PATH = MODEL_DIR / f"{EXPERIMENT_NAME}.pkl"

VALIDATION_ROOT = Path("./validation")
VALIDATION_DIR = VALIDATION_ROOT / EXPERIMENT_NAME

OUTPUT_DIR = Path("./output")

TEST_PATH = DATA_DIR / "test.csv"
SAMPLE_SUB_PATH = DATA_DIR / "sample_submission.csv"
OUTPUT_PATH = OUTPUT_DIR / "submission.csv"


ID = "row_id"


# ============================================================
# CatBoost preprocessing
# ============================================================

def prepare_catboost(
    df: pd.DataFrame,
    cat_cols: list[str],
):

    out = df.copy()

    for col in cat_cols:

        if col in out.columns:

            out[col] = (
                out[col]
                .fillna("__MISSING__")
                .astype(str)
            )

    return out


# ============================================================
# Main
# ============================================================

def main():

    # --------------------------------------------------------
    # File checks
    # --------------------------------------------------------

    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            MODEL_PATH
        )

    if not TEST_PATH.exists():
        raise FileNotFoundError(
            TEST_PATH
        )

    if not SAMPLE_SUB_PATH.exists():
        raise FileNotFoundError(
            SAMPLE_SUB_PATH
        )

    # --------------------------------------------------------
    # Load frozen artifact
    # --------------------------------------------------------

    artifact = joblib.load(
        MODEL_PATH
    )

    if (
        artifact.get(
            "experiment_name"
        )
        != EXPERIMENT_NAME
    ):
        raise RuntimeError(
            "Artifact experiment mismatch"
        )

    features = list(
        artifact[
            "features"
        ]
    )

    cat_model = (
        artifact[
            "catboost"
        ][
            "model"
        ]
    )

    cat_cols = list(
        artifact[
            "catboost"
        ][
            "cat_cols"
        ]
    )

    xgb_model = (
        artifact[
            "xgboost"
        ][
            "model"
        ]
    )

    xgb_preprocessor = (
        artifact[
            "xgboost"
        ][
            "preprocessor"
        ]
    )

    cat_weight = float(
        artifact[
            "ensemble"
        ][
            "cat_weight"
        ]
    )

    xgb_weight = float(
        artifact[
            "ensemble"
        ][
            "xgb_weight"
        ]
    )

    if not np.isclose(
        cat_weight
        + xgb_weight,
        1.0,
    ):
        raise RuntimeError(
            "Invalid ensemble weights"
        )

    # --------------------------------------------------------
    # Test
    #
    # 중요:
    # 여기서는 test에서 어떤 통계도 fit하지 않는다.
    # --------------------------------------------------------

    test = pd.read_csv(
        TEST_PATH,
        encoding="utf-8-sig",
    )

    missing = sorted(
        set(features)
        - set(test.columns)
    )

    if missing:
        raise KeyError(
            f"test feature missing: {missing}"
        )

    # ========================================================
    # CatBoost prediction
    # ========================================================

    X_cat = prepare_catboost(
        test[features],
        cat_cols,
    )

    cat_pred_raw = np.asarray(
        cat_model.predict(
            X_cat
        ),
        dtype=np.float64,
    )

    cat_pred = np.clip(
        cat_pred_raw,
        0.0,
        1.0,
    )

    # ========================================================
    # XGBoost prediction
    #
    # transform만 수행.
    # fit / fit_transform 금지.
    # ========================================================

    X_xgb = (
        xgb_preprocessor
        .transform(
            test[features]
        )
    )

    X_xgb = np.asarray(
        X_xgb,
        dtype=np.float32,
    )

    xgb_pred_raw = np.asarray(
        xgb_model.predict(
            X_xgb
        ),
        dtype=np.float64,
    )

    xgb_pred = np.clip(
        xgb_pred_raw,
        0.0,
        1.0,
    )

    # ========================================================
    # Frozen ensemble
    # ========================================================

    prediction = (
        cat_weight
        * cat_pred
        +
        xgb_weight
        * xgb_pred
    )

    prediction = np.clip(
        prediction,
        0.0,
        1.0,
    )

    # ========================================================
    # Submission
    # ========================================================

    submission = pd.read_csv(
        SAMPLE_SUB_PATH,
        encoding="utf-8-sig",
    )

    if len(submission) != len(test):
        raise RuntimeError(
            "sample_submission/test row mismatch"
        )

    # row_id가 sample submission에 있다면
    # test와 순서까지 확인.
    if (
        ID in submission.columns
        and ID in test.columns
    ):

        if not np.array_equal(
            submission[ID].to_numpy(),
            test[ID].to_numpy(),
        ):

            raise RuntimeError(
                "sample_submission/test row_id order mismatch"
            )

    prediction_cols = [
        col
        for col in submission.columns
        if col != ID
    ]

    if len(prediction_cols) != 1:
        raise RuntimeError(
            "sample_submission의 prediction column을 "
            "하나로 결정할 수 없습니다: "
            f"{prediction_cols}"
        )

    prediction_col = (
        prediction_cols[0]
    )

    submission[
        prediction_col
    ] = prediction

    # --------------------------------------------------------
    # Save
    # --------------------------------------------------------

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    submission.to_csv(
        OUTPUT_PATH,
        index=False,
        encoding="utf-8-sig",
    )

    # --------------------------------------------------------
    # Diagnostics
    #
    # test 전체 통계를 모델 입력/보정에 사용하지 않는다.
    # 아래 출력은 사후 로깅일 뿐 prediction에 반영되지 않는다.
    # --------------------------------------------------------

    print("=" * 88)

    print(
        f"Experiment : {EXPERIMENT_NAME}"
    )

    print(
        "Cat weight :",
        cat_weight,
    )

    print(
        "XGB weight :",
        xgb_weight,
    )

    print(
        "Rows       :",
        f"{len(test):,}",
    )

    print(
        "OUTPUT_PATH:",
        OUTPUT_PATH,
    )

    print("=" * 88)


if __name__ == "__main__":
    main()